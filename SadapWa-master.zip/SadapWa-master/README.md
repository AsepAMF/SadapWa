# SadapWa
pkg install bash
pkg install figlet
pkg install pip2
pip2 install lolcat
pkg install unzip
git clone https://github.com/kingcracker/SadapWa
cd SadapWa
unzip sadap.zip
cd sadap
sh sadap.sh
